﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using LimayracIsContactList.Infrastructure.Data;

namespace LimayracIsContactList.Application.Services
{
    public class AllServices
    {
        public void InstantiateServices(IServiceCollection services, IConfiguration configuration)
        {
         
            
        }
    }
}
