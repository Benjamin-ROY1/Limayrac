﻿using LimayracIsContactList.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace LimayracIsContactList.Infrastructure.Data
{
    public interface IUnitOfWork
    {
        IRepository<Entreprise> EntreprisesRepository { get; }
        IRepository<Service> Services { get; }
        void Commit();
    }
}
