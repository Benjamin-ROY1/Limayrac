﻿using AutoMapper;
using LimayracIsContactList.Infrastructure.Data;
using LimayracIsContactList.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LimayracIsContactList.Infrastructure.Repository
{
    public class ServiceRepository
    {
        /// <summary>
        /// Gets or sets the context.
        /// </summary>
        /// <value>
        /// The context.
        /// </value>
        public LimayracIsContactListContext _context { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="EntrepriseRepository"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        public ServiceRepository(LimayracIsContactListContext context)
        {
            this._context = context;
        }

        /// <summary>
        /// Gets all.
        /// </summary>
        /// <returns>all the service</returns>
        public IList<Service> GetAll()
        {
            return _context.Service.ToList();
        }

        /// <summary>
        /// Inserts the specified service to insert.
        /// </summary>
        /// <param name="serviceToInsert">The service to insert.</param>
        public void Insert(Service serviceToInsert)
        {
            this._context.Service.Add(serviceToInsert);
            this._context.SaveChanges();
        }

        /// <summary>
        /// Updates the specified service.
        /// </summary>
        /// <param name="serviceToUpdate">The service to update.</param>
        public void Update(Service serviceToUpdate)
        {
            this._context.Service.Update(serviceToUpdate);
            _context.SaveChanges();
        }

        /// <summary>
        /// Deletes the specified service.
        /// </summary>
        /// <param name="serviceToDelete">The service to delete.</param>
        public void Delete(int id)
        {
            this._context.Service.Remove(this._context.Service.Find(id));
            _context.SaveChanges();
        }

        /// <summary>
        /// Finds the by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public Service FindById(int id)
        {
            return this._context.Service.Find(id);
        }
    }
}
