﻿using AutoMapper;
using LimayracIsContactList.Infrastructure.Data;
using LimayracIsContactList.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LimayracIsContactList.Infrastructure.Repository
{
    public class EntrepriseRepository
    {
        /// <summary>
        /// Gets or sets the context.
        /// </summary>
        /// <value>
        /// The context.
        /// </value>
        public LimayracIsContactListContext _context { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="EntrepriseRepository"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        public EntrepriseRepository(LimayracIsContactListContext context)
        {
            this._context = context;
        }

        /// <summary>
        /// Gets all.
        /// </summary>
        /// <returns>all the entreprise</returns>
        public IList<Entreprise> GetAll()
        {
            return _context.Entreprise.ToList();
        }

        /// <summary>
        /// Inserts the specified entreprise to insert.
        /// </summary>
        /// <param name="entrepriseToInsert">The entreprise to insert.</param>
        public void Insert(Entreprise entrepriseToInsert)
        {
            this._context.Entreprise.Add(entrepriseToInsert);
            this._context.SaveChanges();
        }

        /// <summary>
        /// Updates the specified entreprise.
        /// </summary>
        /// <param name="entrepriseToUpdate">The entreprise to update.</param>
        public void Update(Entreprise entrepriseToUpdate)
        {
            this._context.Entreprise.Update(entrepriseToUpdate);
            _context.SaveChanges();
        }

        /// <summary>
        /// Deletes the specified entreprise.
        /// </summary>
        /// <param name="entrepriseToDelete">The entreprise to delete.</param>
        public void Delete(int id)
        {
            this._context.Entreprise.Remove(this._context.Entreprise.Find(id));
            _context.SaveChanges();
        }

        /// <summary>
        /// Finds the by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public Entreprise FindById(int id)
        {
            return this._context.Entreprise.Find(id);
        }
    }
}
