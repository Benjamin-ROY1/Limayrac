﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LimayracIsContactList.Infrastructure.Models
{
    public class Service
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int EntrepriseId { get; set; }

        public virtual Entreprise Entreprise { get; set; }

        public virtual ICollection<Contact> Contacts { get; set; }
    }
}
